package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class IfStatement<E, S> extends SingleStatement {

	private MyExpression condition;
	private MyStatement ifBody;
	private MyStatement elseBody;
	
	public IfStatement(E condition, S ifBody, S elseBody) {
		this.condition = (MyExpression) condition;
		this.ifBody = (MyStatement) ifBody;
		this.elseBody = (MyStatement) elseBody;
	}
	
	@Override
	public double execute(Program program, double remainingTime) throws ModelException {
		if ((boolean) this.condition.evaluate(program))
			return (this.ifBody).execute(program, remainingTime);
		else {
			if (this.elseBody == null)
				return remainingTime;
			return (this.elseBody).execute(program, remainingTime);
		}
	}
}
