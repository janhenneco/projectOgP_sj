package asteroids.programs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.model.Ship;
import asteroids.util.ModelException;

public class Program {

	private boolean completed = false;
	private Ship ship;
	private MyStatement body;
	private Map<String, Object> variables = new HashMap<String, Object>();
	private Map<String, Object> parameters = new HashMap<String, Object>();
	private List<Object> printedObjects = new ArrayList<Object>();
	private boolean whileLoopActive = false;
	
	public Program( MyStatement main) {
		body = main;
	}
	
	public boolean isCompleted() {
		return this.completed;
	}
	
	public void complete() {
		this.completed = true;
	}
	
	public void reset() {
		this.completed = false;
	}
	
	public Ship getShip() {
		return this.ship;
	}
	
	public void setShip(Ship ship) {
		this.ship = ship;
	}
	
	public boolean getWhileLoopActive() {
		return this.whileLoopActive;
	}
	public void setWhileLoopActive(boolean whileLoopActive) {
		this.whileLoopActive = whileLoopActive;
	}
	
	public void addVariable(String name, Object value){
		if (this.variables.containsKey(name)) {
			this.variables.replace(name, value);
		}
		else		
			this.variables.put(name, value);
	}

	public Object getVariable(String name) throws ModelException {
		if (!this.variables.containsKey(name))
			throw new ModelException("Variable name is not defined!");
		return this.variables.get(name);
	}
	
	public void addParameters(String name, Object value){
		if (this.parameters.containsKey(name)) {
			this.parameters.replace(name, value);
		}
		else		
			this.parameters.put(name, value);
	}
	
	public Object getParameters(String name) throws ModelException {
		if (!this.parameters.containsKey(name))
			throw new ModelException("Parameter name is not defined!");
		return this.parameters.get(name);
	}
	
	public void addPrintedObject(Object value){
		if (this.printedObjects == null) 
			printedObjects = new ArrayList<Object>();
		this.printedObjects.add(value);
	}
	
	public List<Object> getPrintedObjects(){
		return this.printedObjects;
	}
	
	public void execute(double dt) throws ModelException {
		double remainingTime = dt;
		try {
			remainingTime = this.body.execute(this, remainingTime);		
			
//			while (! this.completed && remainingTime > 0.2) {
//			remainingTime = this.body.execute(this, remainingTime);
//			//this.getShip().move(0.2);
//			if (remainingTime == dt) break;
//		}
		}
		catch (Exception exc) {
			throw new ModelException("Exception in program!");
		}

		this.completed = true;
	}
}
