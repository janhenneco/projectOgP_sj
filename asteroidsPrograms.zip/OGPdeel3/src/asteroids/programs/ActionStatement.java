package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class ActionStatement extends SingleStatement {

	public ActionStatement(){
		super();
	}
	
	@Override
	protected boolean isActionStatement(){
		return true;
	}
	
	@Override
	public double execute(Program program, double remainingTime) throws IllegalPositionException, IllegalWorldException, IllegalProportionException, IllegalEntityException, IllegalShipException, ModelException  {
		return remainingTime - 0.2;
	}
}
