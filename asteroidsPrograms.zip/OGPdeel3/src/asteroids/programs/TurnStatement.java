package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.model.Ship;
import asteroids.util.ModelException;

public class TurnStatement<E> extends ActionStatement {

	private MyExpression angle;
	
	public TurnStatement(E angle) {
		this.angle = (MyExpression) angle;
	}
	
	@Override
	public double execute(Program program, double remainingTime) throws ModelException {
		remainingTime = super.execute(program, remainingTime);
		
		if (program != null)
			try {
				Ship ship = program.getShip();
				Object angle = this.angle.evaluate(program);
				if(ship.isValidOrientation((double) angle))
					program.getShip().turn((double) angle);
				//else
					//throw new ModelException("Illegal angle.");
			} catch (IllegalTimeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return remainingTime;
	}
}
