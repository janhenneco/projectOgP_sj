package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.util.ModelException;

public class EqualityExpression<E> extends MyExpression {
	
	E e1;
	E e2;
	
	
	public EqualityExpression(E e1, E e2) {
		this.e1 = e1;
		this.e2 = e2;
				
	}

	public Object evaluate(Program program) throws ModelException {
		Object object1 = ((MyExpression) this.e1).evaluate(program);
		Object object2 = ((MyExpression) this.e2).evaluate(program);
		return (object1 == object2);
	}
	
}
