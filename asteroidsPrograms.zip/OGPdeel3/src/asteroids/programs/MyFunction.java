package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class MyFunction<S> {

	private String functionName;
	private S body;
	
	public MyFunction(String functionName, S body) {
		this.functionName = functionName;
		this.body = body;
	}
	
	public void execute(Program program, double remainingTime) throws IllegalPositionException, IllegalWorldException, IllegalProportionException, IllegalEntityException, IllegalTimeException, IllegalShipException, IllegalRadiusException, ModelException {
		((MyStatement) this.body).execute(program, remainingTime);
		program.addParameters(this.functionName, this.body);
	}
}
