package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class PrintStatement<E> extends MyStatement {

	MyExpression value;
	
	public PrintStatement(E value) {
		this.value = (MyExpression) value;
	}

	@Override
	public double execute(Program program, double remainingTime) throws ModelException {
		remainingTime = super.execute(program, remainingTime);
		Object printedobject = value.evaluate(program);
		program.addPrintedObject(printedobject);
		System.out.println(printedobject);
		return remainingTime;
	}
}
