package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Entity;

public class NullExpression extends EntityExpression {

	public NullExpression() {
		
	}

	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		return (Entity) null;
	}
}
