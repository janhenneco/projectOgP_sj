package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class AssignmentStatement<E> extends SingleStatement {

	private String variableName;
	private MyExpression expression;
	private Object value;
	
	public AssignmentStatement(String variableName, E value) {
		this.variableName = variableName;
		this.expression = (MyExpression) value;
	}
	
	@Override
	public double execute(Program program, double remainingTime) throws ModelException {
		value = this.expression.evaluate(program);
		
		program.addVariable(this.variableName, this.value);
		
		return remainingTime;
	}
}
