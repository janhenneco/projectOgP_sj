package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Ship;

public class GetDirectionExpression extends MyExpression {
	
	public GetDirectionExpression() {
	
	}

	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		return ship.getOrientation();
	}
}
