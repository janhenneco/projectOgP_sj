package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.util.ModelException;

public class SqrtExpression<E> extends MyExpression{

	private MyExpression expression;
	
	public SqrtExpression(E e) {
		this.expression = (MyExpression) e;
		}
	
	@Override
	public Object evaluate(Program program) throws ModelException {
		double value = (double) this.expression.evaluate(program);
		return Math.sqrt(value);
	}
}
