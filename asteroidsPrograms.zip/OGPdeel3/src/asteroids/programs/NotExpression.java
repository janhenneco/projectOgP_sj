package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.util.ModelException;

public class NotExpression<E> extends MyExpression {
	
	MyExpression e;
	
	public NotExpression(E e) {
		this.e = (MyExpression) e;
	}
	
	@Override
	public Object evaluate(Program program) throws ModelException {
		Object object = (this.e).evaluate(program);
		return (object);
	}
}
