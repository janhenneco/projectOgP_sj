package asteroids.programs;

import java.util.Iterator;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Asteroid;
import asteroids.model.Collision;
import asteroids.model.Entity;
import asteroids.model.Ship;

public class ShipExpression extends EntityExpression {

	
	public ShipExpression() {
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		double shortestDistance = Double.POSITIVE_INFINITY;
		Ship shortestShip = null;
		
		Iterator<Ship> shipIterator = (Iterator<Ship>) Ship.getShips(ship.getWorld()).iterator();
		while (shipIterator.hasNext()) {
			Ship otherShip = shipIterator.next();
			double distance = otherShip.getDistanceBetween(ship);
			if((distance < shortestDistance) && (otherShip != ship)){
				shortestDistance = distance;
				shortestShip = otherShip;
			}
		}
		
		return shortestShip;
	}
}

