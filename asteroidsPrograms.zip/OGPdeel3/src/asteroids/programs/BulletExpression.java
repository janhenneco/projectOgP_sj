package asteroids.programs;

import java.util.Set;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Bullet;
import asteroids.model.Ship;
import asteroids.model.World;

public class BulletExpression extends EntityExpression {
	
	public BulletExpression() {
		
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		World world = ship.getWorld();
		
		if (world != null) {
			Set<Bullet> firedBullets = ship.getFiredBullets();
			int size = firedBullets.size();
			if (size > 0) {
				Object[] bulletArray = firedBullets.toArray();
				int random = (int) (Math.random()*((size-1)+0));
				return bulletArray[random];
			}
			else 
				return null;
			
		}
		else
			return null;
			
		
	}
	

}
