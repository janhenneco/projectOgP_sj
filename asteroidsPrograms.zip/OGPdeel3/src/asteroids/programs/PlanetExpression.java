package asteroids.programs;

import java.util.Iterator;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.MinorPlanet;
import asteroids.model.Collision;
import asteroids.model.Entity;
import asteroids.model.Ship;

public class PlanetExpression extends EntityExpression {

	
	public PlanetExpression() {
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		double shortestDistance = Double.POSITIVE_INFINITY;
		MinorPlanet shortestMinorPlanet = null;
		
		Iterator<MinorPlanet> minorPlanetIterator = (Iterator<MinorPlanet>) MinorPlanet.getMinorPlanets(ship.getWorld()).iterator();
		while (minorPlanetIterator.hasNext()) {
			MinorPlanet minorPlanet = minorPlanetIterator.next();
			double distance = minorPlanet.getDistanceBetween(ship);
			if(distance < shortestDistance){
				shortestDistance = distance;
				shortestMinorPlanet = minorPlanet;
			}
		}
		
		return shortestMinorPlanet;
	}
}

