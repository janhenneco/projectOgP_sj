package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Ship;
import asteroids.util.ModelException;

public class GetVXExpression<E> extends MyExpression {
	
	private MyExpression expression;
	
	public GetVXExpression(E e) {
		this.expression = (MyExpression) e;
	}

	@Override
	public Object evaluate(Program program) throws ModelException {
		if (this.expression instanceof SelfExpression) {
			Ship ship = program.getShip();
			return ship.getVelocity()[0];
		}
		else
			throw new ModelException("Wrong expression!");
	}
}