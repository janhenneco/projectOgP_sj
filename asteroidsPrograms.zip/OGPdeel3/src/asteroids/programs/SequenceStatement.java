package asteroids.programs;

import java.util.Iterator;
import java.util.List;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.model.Entity;
import asteroids.model.Ship;
import asteroids.util.ModelException;

public class SequenceStatement<S> extends MyStatement {

	private List<S> statements;
	Iterator<S> sIterator;
	boolean allStatementsExecuted = false;
	
	public SequenceStatement(List<S> statements){
		this.statements = statements;
		sIterator = statements.iterator();
	}
	
	@Override
	public double execute(Program program, double dt) throws ModelException {
		double remainingTime = dt;

		this.allStatementsExecuted = ! sIterator.hasNext();
		
		boolean breakActive = false;
		
		while (sIterator.hasNext()) {
			if (breakActive) break;
			if (remainingTime >= 0.2) {
				S statement = sIterator.next();
				remainingTime = ((MyStatement) statement).execute(program, remainingTime);
				if (statement instanceof BreakStatement)
					breakActive = true;
				//program.getShip().getWorld().evolve(0.2, null);
			}
			else break;
		}		
		
		return remainingTime;
	}
	
	public void resetIterator() {
		sIterator = statements.iterator();
	}
	
	public boolean allStatementsExecuted () {
		return this.allStatementsExecuted;
	}
}
