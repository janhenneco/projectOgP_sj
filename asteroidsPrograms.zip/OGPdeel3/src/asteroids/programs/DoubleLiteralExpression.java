package asteroids.programs;

public class DoubleLiteralExpression extends MyExpression {

	double value;
	
	public DoubleLiteralExpression(double value) {
		this.value = value;
	}

	@Override
	public Object evaluate(Program program) {
		return value;
	}
}
