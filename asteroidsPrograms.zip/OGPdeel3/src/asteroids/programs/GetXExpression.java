package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Entity;
import asteroids.model.Ship;
import asteroids.util.ModelException;

public class GetXExpression<E> extends MyExpression{

	private MyExpression expression;
	
	public GetXExpression(E expression) {
		this.expression = (MyExpression) expression;
	}
	
	@Override
	public Object evaluate(Program program) throws ModelException {
		return ((Ship) this.expression.evaluate(program)).getPosition()[0];
	}	
}
