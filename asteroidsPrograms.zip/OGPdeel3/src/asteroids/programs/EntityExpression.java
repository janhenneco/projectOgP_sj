package asteroids.programs;

public class EntityExpression extends MyExpression {

}
