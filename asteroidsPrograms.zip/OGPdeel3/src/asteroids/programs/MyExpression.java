package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.util.ModelException;

public class MyExpression {

	public MyExpression()  {
		
	}
	
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException, ModelException {
		return true;
	}
}
