package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class BreakStatement extends SingleStatement {
	
	public BreakStatement() {
		
	}

	@Override
	public double execute(Program program, double remainingTime) throws ModelException {
		remainingTime = super.execute(program, remainingTime);
		
		if (!program.getWhileLoopActive())
			throw new ModelException("Break outside a while loop!");
		
		return remainingTime;
	}
}
