package asteroids.programs;



import java.util.Arrays;
import java.util.Set;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Entity;
import asteroids.model.Ship;
import asteroids.model.World;

public class AnyExpression extends EntityExpression {
	
	AnyExpression() {
		
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		World world = ship.getWorld();
		
		Set<Entity> entities = world.getEntities();
		int size = entities.size();
		Object[] entityArray = entities.toArray();
		if (size == 1) 
			return entityArray[0];
		else {
			int random = (int) (Math.random()*((size-1)+0));
			if (!(entityArray[random] == ship))
				return entityArray[random];
			else if (random + 1 <= size)
				return entityArray[random + 1];
			else
				return entityArray[random - 1];			
		}
	}
	

}
