package asteroids.programs;

import asteroids.util.ModelException;

public class ReadVariableExpression extends MyExpression {
	
	String variableName;
	
	public ReadVariableExpression(String variableName) {
		this.variableName = variableName;
	}

	@Override
	public Object evaluate(Program program) throws ModelException {
		
		return program.getVariable(variableName);
	}
	
	public String getVariableName() {
		return this.variableName.toString();
	}
	
}
