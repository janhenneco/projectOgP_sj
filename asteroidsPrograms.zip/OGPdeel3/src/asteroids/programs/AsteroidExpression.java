package asteroids.programs;

import java.util.Iterator;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Asteroid;
import asteroids.model.Collision;
import asteroids.model.Entity;
import asteroids.model.Ship;

public class AsteroidExpression extends EntityExpression {

	
	public AsteroidExpression() {
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		double shortestDistance = Double.POSITIVE_INFINITY;
		Asteroid shortestAsteroid = null;
		
		Iterator<Asteroid> asteroidIterator = (Iterator<Asteroid>) Asteroid.getAsteroids(ship.getWorld()).iterator();
		while (asteroidIterator.hasNext()) {
			Asteroid asteroid = asteroidIterator.next();
			double distance = asteroid.getDistanceBetween(ship);
			if(distance < shortestDistance){
				shortestDistance = distance;
				shortestAsteroid = asteroid;
			}
		}
		
		return shortestAsteroid;
	}
}
