package asteroids.programs;

public class SelfExpression extends MyExpression{

	public SelfExpression() {
		
	}
	
	@Override
	public Object evaluate(Program program) {
		return program.getShip();
	}
}
