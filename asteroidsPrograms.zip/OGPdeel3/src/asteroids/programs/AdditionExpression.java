package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.util.ModelException;

public class AdditionExpression<E> extends MyExpression {

	MyExpression expression1;
	MyExpression expression2;
	
	public AdditionExpression(E e1, E e2) {
		this.expression1 = (MyExpression) e1;
		this.expression2 = (MyExpression) e2;
	}

	@Override
	public Object evaluate(Program program) throws ModelException {
		double value1= (double) this.expression1.evaluate(program);
		double value2= (double) this.expression2.evaluate(program);
		return value1 + value2;
	}
}
