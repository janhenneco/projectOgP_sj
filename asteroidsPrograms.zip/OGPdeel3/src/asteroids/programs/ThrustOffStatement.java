package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class ThrustOffStatement extends ActionStatement {
	
	public ThrustOffStatement() {
		
	}
	
	@Override
	public double execute(Program program, double remainingTime) throws ModelException {
		remainingTime = super.execute(program, remainingTime);
		
		if (program != null)
			program.getShip().setThrusterActive(false);
		
		return remainingTime;
	}
}
