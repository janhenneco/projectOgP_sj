package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class WhileStatement<S, E> extends SingleStatement {

	private E condition;
	private S body;
	
	public WhileStatement(E condition, S body){
		this.body = body;
		this.condition = condition;
	}
	
	@Override
	public double execute(Program program, double remainingTime) throws ModelException {

		program.setWhileLoopActive(true);
		while (evaluateCondition(program) && remainingTime > 0.2) {
			remainingTime = ((MyStatement) this.body).execute(program, remainingTime);
			if (this.body instanceof SequenceStatement<?>) {
				((SequenceStatement<?>) this.body).resetIterator();
			}
		}
		program.setWhileLoopActive(false);
		
		return remainingTime;
	}
	
	private boolean evaluateCondition(Program program) throws ModelException {
		MyExpression condition = (MyExpression) this.condition;
		boolean conditionIsTrue = false;
		
		if (condition instanceof ReadVariableExpression && ((ReadVariableExpression) condition).getVariableName().equals("true")) conditionIsTrue = true;
		else if (condition instanceof ReadVariableExpression && ((ReadVariableExpression) condition).getVariableName().equals("false")) conditionIsTrue = false;
		else {
			conditionIsTrue = (boolean) condition.evaluate(program);
		}		
		return conditionIsTrue;
	}
}
