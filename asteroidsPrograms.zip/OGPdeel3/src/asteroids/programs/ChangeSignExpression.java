package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;

public class ChangeSignExpression extends MyExpression {
	
	DoubleLiteralExpression value;
	
	public ChangeSignExpression(DoubleLiteralExpression value) {
		this.value = value;
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		double value = (double) this.value.evaluate(program);
		return -value;
	
	}

}
