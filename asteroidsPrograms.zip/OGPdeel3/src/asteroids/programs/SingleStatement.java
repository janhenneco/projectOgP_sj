package asteroids.programs;

import asteroids.exceptions.IllegalEntityException;
import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalProportionException;
import asteroids.exceptions.IllegalRadiusException;
import asteroids.exceptions.IllegalShipException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.exceptions.IllegalWorldException;
import asteroids.util.ModelException;

public class SingleStatement extends MyStatement {

	public SingleStatement() {
		
	}

	@Override
	public double execute(Program program, double remainingTime) throws IllegalPositionException, IllegalWorldException, IllegalProportionException, IllegalEntityException, IllegalTimeException, IllegalShipException, IllegalRadiusException, ModelException {
		return remainingTime;
	}
}
