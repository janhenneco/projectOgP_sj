package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.util.ModelException;

public class MultiplicationExpression<E> extends MyExpression {
	
	MyExpression e1;
	MyExpression e2;
	
	public MultiplicationExpression(E e1, E e2) {
		this.e1= (MyExpression) e1;
		this.e2= (MyExpression) e2;
	}
	
	@Override
	public Object evaluate(Program program) throws ModelException {
		double value1= (double) this.e1.evaluate(program);
		double value2= (double) this.e2.evaluate(program);
		return value1*value2;
	}

}
