package asteroids.programs;

import java.util.Iterator;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.MinorPlanet;
import asteroids.model.Planetoid;
import asteroids.model.Collision;
import asteroids.model.Entity;
import asteroids.model.Ship;

public class PlanetoidExpression extends EntityExpression {

	
	public PlanetoidExpression() {
	}
	
	@Override
	public Object evaluate(Program program) throws IllegalTimeException, IllegalPositionException {
		Ship ship = program.getShip();
		double shortestDistance = Double.POSITIVE_INFINITY;
		Planetoid shortestPlanetoid = null;
		
		Iterator<Planetoid> planetoidIterator = (Iterator<Planetoid>) Planetoid.getPlanetoids(ship.getWorld()).iterator();
		while (planetoidIterator.hasNext()) {
			Planetoid planetoid = planetoidIterator.next();
			double distance = planetoid.getDistanceBetween(ship);
			if(distance < shortestDistance){
				shortestDistance = distance;
				shortestPlanetoid = planetoid;
			}
		}
		
		return shortestPlanetoid;
	}
}
