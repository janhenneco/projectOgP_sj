package asteroids.programs;

import asteroids.exceptions.IllegalPositionException;
import asteroids.exceptions.IllegalTimeException;
import asteroids.model.Entity;
import asteroids.model.Ship;
import asteroids.util.ModelException;

public class GetRadiusExpression<E> extends MyExpression {
	
	private MyExpression e;
	public GetRadiusExpression(E e) {
		this.e = (MyExpression) e;
	}

	@Override
	public Object evaluate(Program program) throws ModelException {
		Object result = this.e.evaluate(program);
		if (result instanceof Entity) {
			return ((Entity) result).getRadius();
		}
		else {
			return result;
		}
	}
}
